function hitungvolume (a, b){ //menulis sebuah function dan buat nama fungsi jangan lupa () digunakan untuk menyimpan parameter/argumen/bahan baku
	let total, volumeA, volumeB;

	volumeA = a * a * a;
	volumeB = b * b * b;

	total = volumeA + volumeB;

	return total; //mengembalikan sebuah nilai digunakan untuk memberhentikan function
} // {}=(block) sebagai tanda awal dan akhir sebuah fungsi
alert(hitungvolume(1,3)); //menjalankan function
alert(hitungvolume(1,5));
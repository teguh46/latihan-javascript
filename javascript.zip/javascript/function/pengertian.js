function tambah (a,b){ // a,b disebut parameter
	return a + b; //berfungsi untuk mengembalikan nilai 
}
let hasil = tambah(2,5) // memanggil function, 2,5 (apapun didalam ()) disebut argumen
alert (hasil); //menampilkan hasilnya berupa alert

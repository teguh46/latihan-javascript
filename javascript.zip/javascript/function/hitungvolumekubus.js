function jumlahvolume (a,b) {
	
	var volA = a;
	var volB = b;
	var total;
	
	volA = a * a * a;
	volB = b * b * b;
	
	total = volA + volB;
	
	return total;
	
}
alert(jumlahvolume (8,3));
// JavaScript Document
var s = '';

function angka (a){
    for (var i = 1; i <= a; i++){
        s += i + ' ';
        s += '\n';
    }
    return s; 
}
console.log(angka(7));
var s = '';

function segitigasiku(baris){
    for (var i = 1; i <=baris; i++){
        for (var j = 1; j <= i; j++){
            s += i + ' ';
        }
        s += '\n';
    }
    return s;
}
console.log(segitigasiku(6));
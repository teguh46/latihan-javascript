var s = '';

function segitiga (a){
    for (var i = 1; i <= a ; i++){
        for (var j = 1; j <= i ; j++){
            s += '*' + ' ';
        }
            s +='\n';
    }
   
    return s;
}
console.log(segitiga(7));


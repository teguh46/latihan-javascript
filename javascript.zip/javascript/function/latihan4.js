var s = '';

function segitiga (baris){
    for (var i = 1; i <= baris; i++){
        for (var j = baris; j >= 1; j--){
            if (i >= j){
                s += i + ' ';
            }else{
                s += ' ';
            }
        }
        s += '\n';
    }
    return s;
}
console.log(segitiga(8));
var s = '';

function kotak (a, b){

    for (var i = 1; i <= a; i++){
        if (i == 1 || i == a){
            for (var j = 1; j <= a; j++){
                s += j;
            } 
        } else {
            for (var k = 1; k <= b; k++){
                if (k == 1 || k == b){
                  s += i;  
                } else {
                    s += ' ';
                }
            }
        }  
        s += '\n';
    }

    return s;
}
console.log(kotak(5,5));
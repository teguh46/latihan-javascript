var s = '';

function segitiga (baris){
    for (var i = baris; i >= 1; i--){
        for (var j = 1; j <= i; j++){
            s += i;
        }
        s += '\n';
    }
    return s;
}
console.log(segitiga(7));
var s = '';

var pola = 5;

function pascal (n){

    var a = 1;
    var b = 1;

    while (b <= n){
        a *= b;
        b++;
    }
    return a;
}

    for (var i = 0; i < pola; i++){

        for (var j = pola; j >= i; j--){
            s += ' ';
        }

        for (var j = 0 ; j <= i ; j++){

            s += pascal(i) / (pascal (j) * pascal(i-j)) + ' ';
          
        }
        s +='\n';
    }

console.log(s);




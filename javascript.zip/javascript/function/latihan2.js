var s = '';

function angka (baris){
    for ( var i = 1; i <= baris; i++){
        for (var j = 1; j <= baris; j++){
            s += j + ' ';
        }
        s +='\n';
    }
    return s;
}
console.log(angka(9));
var tanya = true;
while ( tanya ){

    // menangkap player (pilihan player)
    var p = prompt ('pilih : gajah, semut, orang'); //untuk menampilkan jendela pengisian

    //membangkitkan bilangan random dengan math.random
    var comp = Math.random();

    if (comp < 0.34){
        comp = 'gajah';
    }else if (comp >= 0.34 && comp < 0.67){
        comp = 'orang';
    }else{
        comp = 'semut';
    }
   
    
    //menentukan rules dan tampilkan hasil
    var hasil = '';
    if (p == comp){
        hasil = 'SERI';
        alert ('Kamu memilih : ' + p + ' dan komputer memilih : ' + comp + '\n Maka hasilnya : kamu ' + hasil); 
    }
    
    else if (p == 'gajah'){
        //if (comp == 'orang'){
        //  hasil = 'MENANG';
        //}else{
        //  hasil = 'KALAH';
        //}
        hasil = (comp == 'orang') ? 'MENANG' : 'KALAH';
        alert ('Kamu memilih : ' + p + ' dan komputer memilih : ' + comp + '\n Maka hasilnya : kamu ' + hasil); 
    }
    
    else if ( p == 'orang'){
        hasil = (comp == 'gajah') ? 'KALAH' : 'MENANG';
        alert ('Kamu memilih : ' + p + ' dan komputer memilih : ' + comp + '\n Maka hasilnya : kamu ' + hasil); 
    }
    
    else if (p == 'semut'){
        hasil = (comp == 'orang') ? 'KALAH' :'MENANG';
        alert ('Kamu memilih : ' + p + ' dan komputer memilih : ' + comp + '\n Maka hasilnya : kamu ' + hasil); 
    }
    
    else {
        alert ('Anda memasukan pilihan yang salah');
    }

    tanya = confirm('Mau Lagi?');  //confirm untuk konfirmasi ya atau tidak
}

alert ('Terima kasih sudah bermain.'); //alert untuk menampilkan keterangan
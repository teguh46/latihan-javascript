//membuat object

//object literal
var mhs1 = {
    nama : 'Teguh subagyo',
    email : 'teguhsubagyo11@gmail.com',
    jurusan : 'Teknik Informatika',
}



var mhs2 ={
    nama : 'Sandika',
    email : 'sandi.01@gmail.com',
    jurusan : 'Teknik Kimia'
}



//function declaration (harus ada varibel, variabel penampung dan return)
function buatobjectmahasiswa (nama,email,jurusan){
        var mhs = {};
            mhs.nama = nama;
            mhs.email = email;
            mhs.jurusan = jurusan;
    return mhs;
}

var mhs3 = buatobjectmahasiswa('Teguh subagyo', 'teguhsubagyo11@gmail.com','Teknik Informatika');

var mhs4 = buatobjectmahasiswa('sandika', 'sandika01@gmail.com','Teknik Kimia');



//constructor (pakai bawaan yaitu : this dan pada pemanggilan harus ada keyword new)
function Mahasiswa (nama, email, jurusan){
    this.nama = nama;
    this.email = email;
    this.jurusan = jurusan;

}

var mhs5 = new Mahasiswa ('Teguh subagyo', 'teguhsubagyo11@gmail.com', 'Teknik Informatika');



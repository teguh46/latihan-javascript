//menambah isi array
// var arr = [];

// arr [0] = 'Teguh';
// arr [1] = 'Subagyo';
// arr [3] = 'Lulus';

// console.log(arr);

//menghapus array
// var arr = [];

// arr [0] = 'Teguh';
// arr [1] = 'Subagyo';
// arr [3] = 'Lulus';

// arr [2] = undefined;
// arr [3] = undefined;
// console.log(arr);


//menampilkan isi array, length = untuk menghitung jumlah elemen pada array

// var nama = ['Teguh', 'Subagyo' ,'Mantap', 'siap'];

// for (var i = 0; i < nama.length; i++) {
//     console.log('Mahasiswa ke - ' + (i+1) + ' : '+ (nama[i]));
// }

//menggunakan method join = menggabungkan seluruh isi array dan diubah menjadi sebuah string
// var nama = ['Teguh', 'Subagyo' ,'Mantap', 'siap'];
//  console.log(nama.join( ' - ' ));

//push = menambah isi elemen pada terakhir array (boleh lebih satu)
// var nama = ['Teguh', 'Subagyo'];

// nama.push('Mantap', 'siap', 'sip');
// console.log(nama.join( ' - ' ));

//pop menghilangkan elemen terakhir pada isi array
// var nama = ['Teguh', 'Subagyo','Mantap', 'siap', 'sip'];

// nama.pop();
// console.log(nama.join( ' - ' ));

//unshift = digunakan untuk menambah isi elemen baru di awal array
// var nama = ['Teguh', 'Subagyo','Mantap'];

// nama.unshift('siap');
// console.log(nama.join( ' - ' ));

//shift = menghilangkan elemen di array
// var nama = ['Teguh', 'Subagyo','Mantap'];

// nama.shift();
// console.log(nama.join( '\n' ));

//splice = menyambung elemen ditengah  
//rumusnya = splice(indexawal, maudihapusberapa, elemenbaru1, elemen2, ...)
// var nama = ['Teguh', 'Subagyo'];

// nama.splice(1,0, 'Mantap', 'sip');
// console.log(nama.join( '\n'));

//slice
//rumusnya = slice(indexawal,indexakhir)
// var nama = ['Teguh', 'Subagyo', 'Mantap', 'Sip'];

// var nama2 = nama.slice(0,3);
// console.log(nama2.join( '\n'));

//forEach = untuk setiap elemen

//var angka = [1,2,3,4,5,6,7,8];

// angka.forEach (function(cetak){ //untuk setiap elemen yang ada pada elemen angka lakukan fungsi berikut ini
//     console.log(cetak);
// });

// var nama = ['Teguh', 'Subagyo', 'Mantap', 'Sip'];

// nama.forEach(function(e, i){
//     console.log('Mahasiswa ke - ' + (i+1) + ' adalah : ' + e);
// });

//Map = mengembalikan nilai array

// var angka = [1,2,4,5,6,3];

// var angka2 = angka.map(function(e){
// return e * 2;
// });

// console.log(angka2.join( ' - '));

//sort = untuk mengurutkan isi array
// var angka = [1,2,4,5,6,3,9,7,8,11,24,22,15,10];

// angka.sort (function(a,b){
//     return a-b;
// });
// console.log(angka.join( '-' ));

//filter = mencari elemen pada array (dapat menemukan beberapa nilai)

// var angka = [1,2,4,5,6,3,9];

// var angka2 = angka.filter(function(a){

//     return a > 4;
// }); 
// console.log(angka2.join( ' - '));

//find = mencari elemen pada array (hanya dapat menemukan satu nilai);

var angka = [1,2,4,5,6,3,9];

var angka2 = angka.find(function(a){

    return a > 6;
});
console.log(angka2);





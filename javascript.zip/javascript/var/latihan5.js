var s = '';

for (var a = 4; a >= 1; a--){
	for (var b = 1; b <= a; b++){
		s += b;
	}
	s += '\n';
}
console.log(s);
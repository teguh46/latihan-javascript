var s = '';

//for (var i = 5; i >=1; i--){
  //  for (var j = 5; j >= 1; j--){
    //    if (j > i){
      //      s += ' ' ;
        //}else {
        //s += i ;
        //}
    //}
    //s +='\n';
//}
//console.log(s);

for (var a = 5; a >= 1; a--){
    for (var b = 5; b >= 1; b--){
        if (b > a){
            s +=' ';
        }else{
            s += a + ' ';
        }
    }
    s +='\n';
}
console.log(s);


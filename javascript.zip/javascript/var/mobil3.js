var mobil = 1;
var jumlahmobil = 10;
var mobilberoperasi = 6;

for (mobil; mobil <= jumlahmobil; mobil++){
	
	if (mobil <= mobilberoperasi) {
		console.log('Mobil No ' + mobil + ' sedang beroperasi dengan baik');
	
	} else {
	console.log('Mobil No ' + mobil  + ' sedang rusak');
		}	
}
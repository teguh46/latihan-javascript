<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Latihan Javascript</title>
</head>

<body>
	
	<script src="bintang4.js"></script>
</body>
</html>
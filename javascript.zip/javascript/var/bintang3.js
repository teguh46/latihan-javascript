var s = ''; //variabel untuk menampung

for (var i = 3; i > 0; i--){ 		//mengulang baris tergantung banyaknya i=3 maka (bintang tampil 3) 
	for (var j = 0; j < i; j++){ 	//mengulang berapa bintang yang akan dicetak tiap baris tertentu 
		
		s += '*'; // berfungsi untuk perintah cetak 
	}
	s += '\n'; //berfungsi untuk mencetak turun disatu baris baru / dibawahnya
}
console.log(s); //berfungsi menampilkan hasil

//hasilnya 
       
 		// ***
 		// **
 		// *
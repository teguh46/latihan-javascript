var s = '';

for (var i = 1; i < 5; i ++){
    for (var j = 1; j <= 5; j++){
        if (i % 2 == 0 ){
            s += '#' + ' ';
        }else{
            s +=  ' ' + '#';
        }        
    }
    s += '\n';
}
console.log(s);
var s = ''; //variabel untuk menampung

for (var i = 0; i < 5; i++){ 		//mengulang baris tergantung banyaknya i=5 maka (bintang tampil 5) 
	for (var j = 0; j <= i; j++){ 	//mengulang berapa bintang yang akan dicetak tiap baris tertentu 
		
		s += '*'; // berfungsi untuk perintah cetak 
	}
	s += '\n'; //berfungsi untuk mencetak turun disatu baris baru / dibawahnya
}
console.log(s); //berfungsi menampilkan hasil

//hasilnya *
        // **
 		// ***
 		// ****
 		// *****
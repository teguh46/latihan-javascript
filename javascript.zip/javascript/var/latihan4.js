// var s = '';
//for (var i = 0 ; i < 5; i++){
	//for (var j = 0; j <= i; j++){
		
	//	s += '*';
	//}
	//s += '\n';
//}
//console.log(s);

var s = '';
for (var a = 1; a <= 5; a++){
	for (var b = 1; b <= a; b++){
		
		s += a + ' ';
	}
	s += '\n';
}
console.log(s);
var jumlahmobil =20; //membuat variabel jumlahmobil dengan nilai 
var mobil = 1; //membuat variabel mobil dengan nilai
while (mobil <= jumlahmobil){ //pengulangan variabel mobil apakah <= jumlah mobil
	console.log('Mobil No. ' + mobil + ' Berjalan dengan Baik'); //menampilkan hasilnya dari pengulangan   
mobil++; //increment atau mengecek apakah sudah benar atau belum
}
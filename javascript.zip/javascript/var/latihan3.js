//var s = '';

//for (var i = 1; i <= 3; i++){
	//for (var j = 1; j <= 5; j++){
		
	//	s += j + ' ' ;
	//}
	//s += '\n';
//}
//console.log(s);

var s ='';

for (var i = 1; i <= 4; i++){
	for (var j = 7 ; j >= 0; j--){
		s += j + ' ';
	}
	s +='\n';
}
console.log(s);
//var a = '';

//for (var i = 0; i < 7; i++){
//	a += '*';
//} 
//console.log(a);

var a = '';
for (var i = 1; i <= 5; i++){
	a += i + '.';
	a += '\n';
}
console.log(a);
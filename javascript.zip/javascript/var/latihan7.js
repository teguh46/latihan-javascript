var s = '';

//for (var i = 1; i <= 5; i++){
  //  for (var j = 5; j >= 1; j--){
   //     if (i >= j){
     //       s += '*';
       // }else {
         //   s += ' ';
        //}
    //}
    //s +='\n';
//}
//console.log(s);

//for (var i = 1; i <= 5; i++){
 //   for (var j = 5; j >= 1; j--){
   //     if (i >=j){
     //       s += i;
       // } else {
        //    s += ' ';
     //   }
 //   }
 //   s +='\n';
//}
// console.log(s);

for (var i = 1; i <= 5; i++){
    for (var j = 5; j >= 1; j--){
        if (i >= j ){
            s += i + ' ';
        }else {
            s += ' ';
        }
    }
    s += '\n';
}
console.log(s);
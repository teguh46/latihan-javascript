var mobil = 1;
var jumlahmobil = 10;
var mobilberoperasi = 6;

for (mobil; mobil <= jumlahmobil; mobil++){
	
	if (mobil <= mobilberoperasi && mobil !== 5 ) {
		console.log('Mobil No ' + mobil + ' sedang beroperasi dengan baik');
	
	} else if ( mobil === 8 || mobil === 10 || mobil === 5){
	console.log('Mobil No ' + mobil  + ' sedang lembur');
	
	}else {
	console.log('Mobil No ' + mobil + ' sedang rusak');
		
	}	
}// JavaScript Document
var jumlahmobil = 10;
var mobilberoperasi = 8;
var mobil = 1; //penggunaan while
while (mobil <= mobilberoperasi){ 
	console.log('Mobil No. ' + mobil + ' Berjalan dengan Baik');  
mobil++; 
}

//penggunaan for
for (mobil <= mobilberoperasi ; mobil <= jumlahmobil ; mobil++){
	console.log('Mobil No. ' + mobil + ' Rusak');
}

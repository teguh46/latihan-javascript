var s = '';

//for (var i = 1; i <= 5; i++){
  //  for (var j = 1; j <= i; j++){
    //        s += i;
    //}
    //s += '\n';
//}
//console.log(s);

//for (var i = 4; i >= 1; i--){
  //   for (var j = 1; j <= i; j++){
    //          s += i;
      //}
    //  s += '\n';
  //}
  //console.log(s);

  for (var i = 1; i <= 5; i++){
      for (var j = 1; j <= i; j++){
             s += '*';
        }
      s += '\n';
    }

   for (var a = 4; a >= 1; a--){
          for (var b = 1; b <= a; b++){
                s += '*';
        }
      s += '\n';
    }
  console.log(s);
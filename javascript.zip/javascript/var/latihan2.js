var s ='';

for (var i = 0; i < 5; i++){
	for (var j = 0; j < 3; j++){
		s += '*';
	}
	s += '\n';
}
console.log(s);
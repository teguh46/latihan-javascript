var s = '';

for (var i = 1; i <= 5; i++){
    for (var j = 5; j >=1; j--){
        if (i >= j){
            s += '*' + ' ';
        }else{
            s += ' ';
        }
    }
    s += '\n';
}

for (var a = 4; a >= 1; a--){
    for (var b = 5; b >= 1; b--){
        if (b > a){
            s += ' ';
        }else{
            s += '*' + ' ';
        }
    }
    s += '\n';
}
console.log(s);
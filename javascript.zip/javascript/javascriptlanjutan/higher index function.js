const angka = [-2, 6, 3, 5, 7, 9, 1, 4, 6, 9, 3, 5];

//mencari angka >=5
//menggunakan for
// const newAngka = []; //array untuk menampung array baru
// for (let i = 1; i < angka.length; i++){
//     if (angka[i] >= 5){ 
//         newAngka.push(angka[i]);
//     }
// }
// console.log(newAngka);

//pakai filter

// const newAngka =  angka.filter(function(a) {
// return a >=5;
// });
// console.log(newAngka);

//pakai arrow function
// const newAngka =  angka.filter(a => a >= 5);
// console.log(newAngka);

//map 
//kalikan semua angka dengan 2
// const newAngka = angka.map(a => a * 2);
// console.log(newAngka);

//reduce
//jumlahkan seluruh elemen pada array
// -2 + 6 + 3 + 5 + 7 + 9 + 1 + 4 + 6 + 9 + 3 + 5
// const newAngka = angka.reduce((accumulator, currentValue) => accumulator + currentValue, 0); //0 = untuk nilai awal (defaultnya 0)
// console.log(newAngka);

//method chaining
//cari angka > 5
//jumlahkan

const hasil = angka.filter (a => a > 5) 
                   .map(a => a * 3)
                   .reduce((acc,cur) => acc + cur);
console.log(hasil);



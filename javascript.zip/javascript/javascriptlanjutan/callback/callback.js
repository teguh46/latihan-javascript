//calback
//syncronous callback

// function halo (nama) {
//     alert(`Halo, ${nama}`)
// }

// function tampil(callback){
// const nama = prompt("masukan nama:");
// callback(nama);
// }

// tampil(nama =>
//     alert(`halo, ${nama}`)
// );

// const mhs = [
//     {
//         "nama" : "Teguh Subagyo",
//         "Nim" : "1503040072",
//         "email" : "teguh11@gmail.com",
//         "jurusan" : "Teknik informatika",
//         "Iddosen" : 1,
//     },
//     {
//         "nama" : "Ahmad",
//         "Nim" : "1503040073",
//         "email" : "Ahmad@gmail.com",
//         "jurusan" : "Teknik informatika",
//         "Iddosen" : 2,
//     },
//     {
//         "nama" : "Doddy",
//         "Nim" : "1503040074",
//         "email" : "Doddy@gmail.com",
//         "jurusan" : "Teknik informatika",
//         "Iddosen" : 3,
//     },

// ];


// console.log('mulai');
// mhs.forEach(m => {
//     for (let i = 0; i < 10000000; i++) {
//         let date = new Date();
//     }
//     console.log(m.nama)
// });
// console.log('selesai');

//asynchronous callback

// function getDataMhs(url, success, error){
//     let xhr = new XMLHttpRequest();
    
//     xhr.onreadystatechange = function(){
//         if (xhr.readyState === 4) {
//             if (xhr.status === 200) {
//                 success(xhr.response);
//             }
//             else if (xhr.status === 404) {
//                 error();
//             }
//         }
//     }
//     xhr.open('get',url);
//     xhr.send();
// }


// getDataMhs('latihancallback.json', 
//         result => {
//         const mhs  = JSON.parse(result);
//         mhs.forEach (m => console.log(m.nama));
//     //   console.log(JSON.parse(result));
//     }, 

//     () => {

//     });
    

//jQuery ajax
$.ajax({
    url:'latihancallback.json',
    success: (mhs) => {
        mhs.forEach( m => console.log(m.nama));
        // console.log(mhs);
    },
    error:(err) => {
        console.log(err.responseText);
    }
});



//tagged tampletes

// const nama = 'Teguh subagyo';
// const umur = 24;

// function coba(strings, ...args){ 
// //     let result = '';
// //     strings.forEach((str, i) => {
// //         result += `${str}${args[i] || ''}`;
// //     });
// // return result;

// return strings.reduce((result, str, i)=> 
//             `${result}${str}${args[i] || ''}`, '');
// }

// const str = coba`Halo, nama saya ${nama}, ${umur} tahun`;

// console.log(str);

//higlight
const nama = 'Teguh subagyo';
const umur = 24;
const email = 'teguhsubagyo11@gmail.com';

function coba(strings, ...args){ 
return strings.reduce((result, str, i)=> 
    `${result}${str}<span class="hl">${args[i] || ''} </span>`, '');
}

const str = coba`Halo, nama saya ${nama}, ${umur} tahun , dan email saya adalah ${email}`;

document.body.innerHTML = str;
console.log(str);
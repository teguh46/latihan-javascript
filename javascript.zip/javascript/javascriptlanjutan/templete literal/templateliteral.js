// HTML fragments

// const mhs = {
//     nama : 'Teguh Subagyo',
//     umur : 24,
//     email : 'Teguhsubagyo11@gmail.com'
// };

// const el = `<div class = "mhs">
//             <h2>${mhs.nama}</h2>
//             <span class = "email">${mhs.email}</span>
//             </div>`;


//looping
// const mhs = [
//     {
//     nama : 'Teguh Subagyo',
//     email : 'Teguhsubagyo11@gmail.com'
//     },

//     {
//     nama : 'surya',
//     email : 'surya11@gmail.com'
//     },

//     {
//     nama : 'Subagyo',
//     email : 'subagyo11@gmail.com'
//     }
// ];

// const el = `<div class = "mhs">
//             ${mhs.map(m => `<ul>
//                 <li>${m.nama}</li>
//                 <li>${m.email}</li>
//             </ul>`).join('')}
//             </div>`;
// document.body.innerHTML = el;


//conditionals
// const lagu = {
//     judul : 'Bad life',
//     penyanyi : 'bring me the horizon',
//     feat : ''
// }

// const el = `<div class = "lagu">
//                 <ul>
//                     <li>${lagu.penyanyi}</li>
//                     <li>${lagu.judul} ${lagu.feat ? `(Feat. ${lagu.feat})` : ''}</li>
//                 </ul>
//             </div>`;

//nasted / HTML fragment bersarang
const mhs = {

    nama : 'Teguh Subagyo',
    semester : 5,
    matakuliah : [
        'Rekayasa web',
        'Pemrograman Lanjut',
        'Pemrograman web',
        'Sistem berorientasi object'
    ] 
};

function CetakMataKuliah(matakuliah){
    return `
    <ol>
    ${matakuliah.map(mk => `<li>${mk}</li>`).join('')}
    </ol>
    `;
}

const el = `<div>
            <h2>${mhs.nama}</h2>
            <span class = "semester"> Semester : ${mhs.semester}</span>
            <h4>Mata kuliah :</h4>
                ${CetakMataKuliah(mhs.matakuliah)}
           </div>`;
document.body.innerHTML = el;
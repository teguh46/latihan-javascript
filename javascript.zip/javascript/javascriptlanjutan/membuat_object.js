//cara membuat object 

//1. object literal : problemnya nama variabel tidak boleh sama
// tidak efektif untuk object yang banyak
// let mahasiswa = {              //membuat variabel dengan let dan membuat object literal dengan {} kurung kurawal buka dan tutup
        //membuat properti , properti berisikan nilai
//     nama : 'Teguh',            //properti nama yang berisi string 'teguh'
//     energi : 10,              //properti energi yang berisi int/number = 10

        //membuat method, method berisi function
//     makan : function (porsi){                //function menerima parameter porsi, nanti dijalankan makan berapa porsi maka akan menambah energi
//         this.energi = this.energi + porsi;   //didalam object ada keyword 'this' yang isinya menambah energi sebelumnya, jadi berapa porsi akan menambah pada energinya
//         console.log(`Hello ${this.nama}, selamat makan`) //pakai string literal( sebelah angka 1 =beptik) `` diisi dengan hello langsung panggil propereti dengan ${this.nama} properti 
//     }
// } 
// //jika dijalankan di consol : mahasiswa.makan(mau berapa porsi contoh : 2 porsi), setelah makan 2 porsi maka energinya nambah jadi 12 karena 10 (default) + hasil inputan yaitu 2 


// let mahasiswa2 = {           //nama variabel tidak boleh sama dengan yang sebelumnya(harus beda)
//     nama : 'sandika',
//     energi : 20,
//     makan : function (porsi){
//         this.energi = this.energi + porsi;
//         console.log(`Hello ${this.nama}, selamat makan`)
//     }
// }

//2. function declaration

// function Mahasiswa(nama,energi){             //function nama function (mahasiswa) akan menerima dua buah parameter nama dan energi 
//     let mahasiswa = {};                      //deklarasikan mau buat objek baru, buat variabel baru dalam bentuk objek, dengan objek kosong (sebagai alias/ penampung)
//         mahasiswa.nama = nama;               //variabel mahasiswa diisi dengan nama sebagai properti, atau apapun yang ada di parameter 
//         mahasiswa.energi = energi;           //variabel mahasiswa diisi dengan energi sebagai properti, atau apapun yang ada di parameter 
           
//         mahasiswa.makan = function (porsi) { //membuat method makan diisi dengan function berapa porsi
//              this.energi += porsi;           //this.energi diisi dengan this.energi ditambah porsi
//              console.log(`Hello ${this.nama}, Selamat makan`);
//         }

//         mahasiswa.main = function(jam){      //buat function main yang parameter diisi dengna jam
//              this.energi -= jam;             //misalnya main berapa jam ?, akan mengurangi energi sesuai jamnya
//              console.log(`Hello ${this.nama}, Selamat bermain`)
//         }

//     return mahasiswa;                    // dikembalikan objeknya
// }

// let teguh = Mahasiswa('Teguh', 10); //buat variabel (teguh) yang diisi dengan penggil nama functionnya isi nilainya 
// let sandika = Mahasiswa('samdika', 20);
// // jika dijalankan di consol yaitu panggil variabelnya, misalnya teguh.makan(mau berapa porsi misal :3) maka energinya akan menambah


//function declaration (object.create) problemnya jika ada method baru harus diingat 
// const methodMahasiswa = {                    //membuat variabel dengan conts karena isinya tidak akan berubah yang bentuknya objek
//     makan : function (porsi) {               
//         this.energi += porsi;
//         console.log(`Hello ${this.nama}, Selamat makan`);
//    },

//    main : function(jam){
//         this.energi -= jam;
//         console.log(`Hello ${this.nama}, Selamat bermain`);
//    },

//    tidur : function(jam){                    
//        this.energi += jam * 2;               jika  mahasiswa tidur maka energinya bertambah jam di kali 2 (nilainya)
//        console.log(`Hello ${this.nama}, selamat tidur`);
//    }
// };

// function Mahasiswa(nama,energi){
//     let mahasiswa = Object.create(methodMahasiswa);      //variabel diisi dengan object.create yang diisi dengan parameternya (objek yang saling terhubung), mengacu ke parent objeknya
//         mahasiswa.nama = nama;
//         mahasiswa.energi = energi;
      
//     return mahasiswa;
// }

// let teguh = Mahasiswa('Teguh', 10);
// let sandika = Mahasiswa('samdika', 20);



//3. constructor (menggunakan keyword new) : tidak perlu menuliskan deklarasi variabel objek dan return karena sudah secara otomatis dilakukan oleh javascripnya

// function Mahasiswa(nama,energi){         

//         this.nama = nama;
//         this.energi = energi;

//         this.makan = function (porsi) {
//             this.energi += porsi;
//             console.log(`Hello ${this.nama}, Selamat makan`);
//         }

//         this.main = function(jam){
//             this.energi -= jam;
//             console.log(`Hello ${this.nama}, Selamat bermain`)
//         }
// }

// let teguh = new Mahasiswa('Teguh', 10);          // variabel baru diisi dengan new nama functionnya, diisi nilainya 
// let sandika = new Mahasiswa('sandika', 20);



//prototype 
function Mahasiswa(nama,energi){        
        this.nama = nama;           // buat properti dengan this.nama diisi dengan nama
        this.energi = energi;       
}

        Mahasiswa.prototype.makan = function (porsi){    //nama objek mahasiswa.prototype.makan yang diisi dengan function
            this.energi += porsi;                        
            return `Hello ${this.nama}, Selamat makan`; 
        }

        Mahasiswa.prototype.main = function (jam){
            this.energi -= jam;                            // jika mahasiswa main maka energinya akan dikurangi jam
            return `Hello ${this.nama}, Selamat bermain`;
        }

        Mahasiswa.prototype.tidur = function (jam){
            this.energi += jam * 2;                         //jika tidur maka energinya akan dikalikan 2  
            return `Hello ${this.nama}, Selamat tidur`;
        }

let teguh =  new Mahasiswa(`Teguh`, 10);



//versi class
// class Mahasiswa {                        //buat class lalu dibuat nama class nya
//     constructor(nama,energi){            //properti sama saja dengan constructor yang berisi parameter
//         this.nama = nama;                //this.nama diisi dengan nama(atau apapun yang ada di class)
//         this.energi = energi;
//     }

//     makan (porsi){                      
//         this.energi += porsi;
//         return `Hello ${this.nama}, Selamat makan`;
//     }
    
//     main (jam){
//         this.energi -= jam;
//         return `Hello ${this.nama}, Selamat bermain`;
//     }
    
//     tidur (jam){
//         this.energi += jam * 2;
//         return `Hello ${this.nama}, Selamat tidur`;
//     }

// }

// let teguh =  new Mahasiswa(`Teguh`, 10);
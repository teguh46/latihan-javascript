//distructuring pada function

// function kalkulasi (a,b){
//     return [a + b, a - b, a * b];
// }

// // const jumlah = penjumlahanperkalian(2,4)[0];
// // const kali = penjumlahanperkalian(2,4)[1];
// // const [jumlah , kali] = penjumlahanperkalian(2,4);
// // console.log(jumlah);
// // console.log(kali);

// //urutan sangat berpengaruh
// const[tambah, kurang, kali, bagi = 'tidak ada'] = kalkulasi (2,4);
// console.log(tambah);
// console.log(kurang);
// console.log(kali);
// console.log(bagi);

// function kalkulasi (a,b) {
//     return{
//         tambah : a + b,
//         kurang : a - b,
//         kali : a *b, 
//         bagi : a /b
//     }
// }
 
// const {kali, bagi, tambah, kurang} = kalkulasi (2,4);
// console.log(bagi);
// console.log(kali);
// console.log(kurang);
// console.log(tambah);

//distructuring function argumen

const mhs1 = {
    nama : 'teguh subagyo',
    umur : 24,
    email : 'teguh11@gmail.com', 
    nilai : {
        tugas : 80,
        uts : 90,
        uas : 80
    }
}

function cetakMhs ({nama, umur, nilai : {tugas,uas,uts}}) {
    return `Hallo nama saya ${nama}, saya berumur = ${umur} tahun dan nilai uas saya adalah ${uas}`;
}

console.log(cetakMhs(mhs1));
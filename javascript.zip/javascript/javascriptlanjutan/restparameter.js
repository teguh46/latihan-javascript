//rest parameter

// function myfunc(){
// // return `a = ${a}, b =${b}, value =${value}`;
// // return value;
// // return Array.from(arguments);
// return [...arguments];
// }
// console.log(myfunc(1,2,3,4));

// function jumlahkan (...angka){
//     let total = 0;
// //     for (const a of angka){
// //         total += a;
// //     }
// // return total;

// return angka.reduce((a,b) =>  a + b);
// }
// console.log(jumlahkan(1,2,3,4,5))

//array distructuring
// const kelompok = ['Teguh', 'Subagyo', 'Doddy', 'Ahmad'];
// const [ketua, wakil, ...anggota] = kelompok;

// console.log(ketua);
// console.log(wakil);
// console.log(anggota);

//object distructuring

// const team ={
//     pm : 'Teguh',
//     frontend : 'Bagyo',
//     backend : 'Subagyo',
//     ux : 'Doddy'
// }

// const {pm, ...myteam} = team;
// console.log(myteam);

//filtering

function filter (type, ...value){
return value.filter(v => typeof v === type);

}

console.log(filter('number', 1,2, 'Teguh', 'Subagyo', false, true,'Bagyo'));
console.log(filter('string', 1,2, 'Teguh', 'Subagyo', false, true,'Bagyo'));
console.log(filter('boolean', 1,2, 'Teguh', 'Subagyo', false, true,'Bagyo'));
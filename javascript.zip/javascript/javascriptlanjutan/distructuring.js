//distructuring variabel//assaigment

//array
// const perkenalan = ['Halo', 'nama', 'saya', 'teguh subagyo'];

// //const [salam, satu, dua, nama] = perkenalan;
// //bisa diskip tapi jangan dihapus komanya
// const [salam , , , nama] = perkenalan;

// console.log(salam);
// // console.log(satu);
// // console.log(dua);
// console.log (nama);

//swap item /menukar isinya
// let a = 1;
// let b = 2;
// console.log(a);
// console.log(b);

// [a,b] = [b,a];
// console.log(a);
// console.log(b);

//return value pada function
// function coba (){
//     return[1,2];
// }

// const [a , b] = coba();
// //console.log(a);
// console.log(b);

//rest parameter
//nama variabel bebas
// const [a, ...value] = [1,2,3,4];

// console.log(a);
// console.log(value);

//disctructuring object
// const mhs = {
//     nama : 'teguh subagyo',
//     umur :24
// }
// //nama variabel harus sama dengan propertynya
// const {nama, umur} = mhs;
// console.log(nama);

//assaigment tanpa deklarasi object
// ({ nama, umur } ={
//     nama : 'teguh subagyo',
//     umur :24
// });
// //nama variabel harus sama dengan propertynya
// console.log(nama);

//assaigment ke variabel baru 

// const mhs = {
//     nama : 'teguh subagyo',
//     umur :24
// }
// //nama variabel harus sama dengan yang variabel baru dibuat
// const {nama: n, umur : u} = mhs;
// console.log(u);

//memberikan default value
// const mhs = {
//     nama : 'teguh subagyo',
//     umur :24,
//     email : 'teguhsubagyo11@gmail.com'
// }
// //nama variabel harus sama dengan propertynya
// const {nama, umur, email = 'email@gmail.com'} = mhs;
// console.log(email);

//memberikan nilai default dan assaigment ke variabel baru
// const mhs = {
//     nama : 'teguh subagyo',
//     umur :24,
//     email : 'teguhsubagyo11@gmail.com'
// }
// //nama variabel harus sama dengan yang variabel baru dibuat
// const {nama: n, umur : u, email: e ='email@gmail.com'} = mhs;
// console.log(e);

//rest parameter
// const mhs = {
//     nama : 'teguh subagyo',
//     umur :24,
//     email : 'teguhsubagyo11@gmail.com'
// }
// //nama variabel bebas tapi untuk rest parameter
// const {nama, ...value} = mhs;
// console.log(nama);
// console.log(value);

//mengambil field pada object,setelah dikirim sebagai parameter untuk function

const mhs = {
    id : 123,
    nama : 'teguh subagyo',
    umur :24,
    email : 'teguhsubagyo11@gmail.com'
}

function getIdMhs({id}){
    return id;
}

console.log(getIdMhs(mhs));


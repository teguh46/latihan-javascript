//membuat arrow function : meringkas dari function expression

// belum menngunakan arrow function
// const tampilNama = function (nama){
//     return `hello, ${nama}`;
// }
// console.log(tampilNama('Teguh subagyo'));

//cara 1. menggunakan 1 parameter
// const tampilNama = nama => { //buat variabel lalu nama function diisi dengan nama
//     return `hello, ${nama}`; //dikembalikan nilai nama
// }
// console.log(tampilNama(`Teguh subagyo`)); //jalankan nama function isikan argumennya

//2. menggunakan 2 parameter
// const tampilNama = (nama, waktu) => {
//     return `Selamat ${waktu}, ${nama}`
// }
// console.log(tampilNama(`teguh`, `malam`))

//3. implisit return, jika satu parameter dan isinya hanya return
// const tampilNama = nama => `hello, ${nama}`;
// console.log(tampilNama(`Teguh subagyo`));

//jika tanpa parameter, wajib menggunakan () kurung buka dan tutup
// const tampilNama = () => `hello world`;
// console.log(tampilNama()); 

//menggunakan cara biasa
// let mahasiswa = [`Teguh subagyo`, `Mantap`];

// let jmlhuruf = mahasiswa.map(function(nama){
//     return nama.length;
// });
// console.log(jmlhuruf);

//menggunakan arrow function dalam bentuk array
// let mahasiswa = [`Teguh subagyo`, `Mantap`];

// let jmlhuruf = mahasiswa.map(nama => nama.length);
// console.log(jmlhuruf);

//menggunakan arrow function dalam bentuk object
// let mahasiswa = [`Teguh subagyo`, `Mantap`];

// let jmlhuruf = mahasiswa.map( nama => ({ nama : nama, jmlhuruf : nama.length}));

// console.table(jmlhuruf);

//konsep this pada arrow function

//constructor function
// const Mahasiswa = function () {
//     this.nama = 'Teguh subagyo';
//     this.umur = 24;
//     this.sayhello =function (){
//         console.log (`Hello, Nama saya ${this.nama}, dan saya ${this.umur} tahun`);
//     }
// }

// const teguh = new Mahasiswa();

//arrow function (tidak semua function dibuat menggunakan arrow function, tapi method bisa)
// const Mahasiswa = function () {
//     this.nama = 'Teguh subagyo';
//     this.umur = 24;
//     this.sayhello = () => {
//         console.log (`Hello, Nama saya ${this.nama}, dan saya ${this.umur} tahun`);
//     }
// }

// const teguh = new Mahasiswa();

//contoh 2
// const Mahasiswa = function () {
//     this.nama = 'Teguh subagyo';
//     this.umur = 24;
//     this.sayhello = () => {
//         console.log (`Hello, Nama saya ${this.nama}, dan saya ${this.umur} tahun`);
//     }
//     setInterval (() => {
//         console.log(this.umur++);
//     }, 500);
// }

// const teguh = new Mahasiswa();

